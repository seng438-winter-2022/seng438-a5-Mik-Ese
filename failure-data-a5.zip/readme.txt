T: time interval
FC: failure count
E: execution time measured in hours
F:failure identification work measured in person hours
C: computer time failure identification measured in hours  

More information at 
https://www.sciencedirect.com/science/article/pii/S2352711021001588